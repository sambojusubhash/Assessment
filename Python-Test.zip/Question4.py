student = {
    "name": "John",
    "age": 21,
    "marks": {"math": 80, "science": 90}
}
#Question-1
print(student.get("name")) 
#Question-2
student["grade"] = "A"
#Question-3
student.update({"age": 22})
#Question-4
student.pop("age")
#Question-5
student.popitem()
#Question-6
print(student.keys())
#Question-7
print(student.values())
#Question-8
print(student.items())
#Question-9
student.setdefault("city", "Hyderabad")
#Question-10
student.update({"phone": "1234567890"})