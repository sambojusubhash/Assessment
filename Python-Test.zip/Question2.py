tup = (10, 20, 30, 40, 50, 20, 60)
#Question-1
print(tup.count(20))
#Question-2
print(tup.index(40))  
#Question-3
temp = list(tup)
temp.append(70)
tup = tuple(temp)
print(tup)
#Question-4
print(tup[2:6]) 
#Question-5
t2 = (80, 90)
tup = tup + t2
print(tup)
#Question-6
print(tup * 2)
#Question-7
print(50 in tup)
#Question-8
a, b, c, d, e, f, g, *rest = tup
print(a, b, c)
print(rest)
#Question-9
#Not Possible
#Question-10
nested = (1, 2, (3, 4, 5))
print(nested[2][1])