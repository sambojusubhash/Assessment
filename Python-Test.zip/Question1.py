data = [10, 20, 30, 40, 50, 20, 30, 60, [70, 80], 90]
#Question-1
data.append([100, 110])
#Question-2
data.extend([120, 130])
#Question-3
data.insert(2, 25)
#Question-4
data.remove(20)
#Question-5
last_element = data.pop()
print("Popped element:", last_element)
#Question-6
count_30 = data.count(30)
print("Count of 30:", count_30)
#Question-7
index_40 = data.index(40)
print("Index of 40:", index_40)
#Question-8
data.reverse()
